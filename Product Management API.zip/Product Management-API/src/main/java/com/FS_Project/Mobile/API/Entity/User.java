package com.FS_Project.Mobile.API.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import org.springframework.web.multipart.MultipartFile;
// create table user(username varchar(20),password varchar(20),emailid varchar(20))

	@Entity
	public class User 
	{
		
		
		private String first_name;
		private String last_name;
		private long  phone_no;
		private String email_id;
		@Id
		private String username;
		private String password;	
		private String imagepath;
		
		transient MultipartFile images;
		
		
		public MultipartFile getImages() {
			return images;
		}
		
		
		
		 public String getImagepath() {
				return imagepath;
			}
			public void setImagepath(String imagepath) {
				this.imagepath = imagepath;
			}
		public void setImages(MultipartFile images) {
			this.images = images;
		}
		
		
		
		public String getFirst_name() {
			return first_name;
		}
		public void setFirst_name(String first_name) {
			this.first_name = first_name;
		}
		public String getLast_name() {
			return last_name;
		}
		public void setLast_name(String last_name) {
			this.last_name = last_name;
		}
		public long getPhone_no() {
			return phone_no;
		}
		public void setPhone_no(long phone_no) {
			this.phone_no = phone_no;
		}
		public String getEmail_id() {
			return email_id;
		}
		public void setEmail_id(String email_id) {
			this.email_id = email_id;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
		
			
	}


