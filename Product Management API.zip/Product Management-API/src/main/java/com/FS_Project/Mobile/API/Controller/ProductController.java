package com.FS_Project.Mobile.API.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.FS_Project.Mobile.API.Entity.Product;
import com.FS_Project.Mobile.API.Entity.ProductInfo;
import com.FS_Project.Mobile.API.Service.ProductService;



@RequestMapping("productapi")
@RestController
public class ProductController {

	@Autowired
	ProductService ps;
	
	@RequestMapping("allProducts")
	public List<Product> allProducts()
	{
		
		return ps.allProducts();
	}
	
	@RequestMapping("viewproduct/{pid}")
    public Product viewproduct(@PathVariable int pid)
	{
		return ps.viewproduct(pid);
	}
	
	@RequestMapping("allProductWithCategory/{pid}")
	public List<ProductInfo> allProductsWithCategory(@PathVariable int pid)
	{
		return ps.allProductWithCategory(pid);
	}
	
	@RequestMapping("deleteProduct/{pid}")
	public Product deleteProduct(@PathVariable int pid)
	{
		return ps.deleteProduct(pid);
	}
	
	
}


