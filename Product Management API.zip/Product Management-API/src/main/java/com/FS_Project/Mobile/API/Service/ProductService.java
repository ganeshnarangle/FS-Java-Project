package com.FS_Project.Mobile.API.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.FS_Project.Mobile.API.DAO.ProductDao;
import com.FS_Project.Mobile.API.Entity.Product;
import com.FS_Project.Mobile.API.Entity.ProductInfo;

@Service
public class ProductService {

	@Autowired
	ProductDao pd;
	

	
	       
	    public Product addProduct(Product product,int cid)
	   	{
	    		return pd.addProduct(product, cid);
	   	}
		
	    
	    
	    public java.util.List<Product> allProducts()
		{
			return pd.allProduct();
		}
		
		public Product viewproduct(int pid)
		{
			return pd.viewproduct(pid);
		}

		public List<ProductInfo> allProductWithCategory(int pid)
		{
			return (List<ProductInfo>) pd.allProductwithCategory(pid);
		}
		
		public Product deleteProduct(int pid)
		{
			return pd.deleteProduct(pid);
		}
		
	}

	
	

