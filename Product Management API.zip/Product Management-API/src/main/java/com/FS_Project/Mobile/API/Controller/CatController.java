package com.FS_Project.Mobile.API.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.FS_Project.Mobile.API.Entity.Category;
import com.FS_Project.Mobile.API.Entity.ObjectNotFoundException;
import com.FS_Project.Mobile.API.Service.CatService;

@RestController
@RequestMapping("categoryapi")
public class CatController {

	@Autowired
	CatService cs;
	
	@PostMapping("saveCategory")
	public Category saveCategory(@RequestBody Category  category ) {
		System.out.println(category); 
		cs.setCategory(category);
		 return category;
	}
	
	
	@RequestMapping("getCategory/{cid}")
    public Category getCategory(@PathVariable int cid) {
		Category category= cs.getCategory(cid);
		
		if(category==null) {
			throw new ObjectNotFoundException("No Record Found with Catg ID "+cid);
			//Raising exception by using throw keyword
		}else {
			return category;
		}
	}

	@RequestMapping("getAllCategory")
	public List<Category> getAllCategory(){
		List<Category>list=cs.getAllCategory();
		return list;
	}
	
	
	
	
	
	@PutMapping("updateCategory")
	public Category updateCategory(@RequestBody Category  category ) {
		return cs.updateCategory(category);
	}
	
	
	@RequestMapping("deleteCategory/{cid}")
    public Category deleteCategory(@PathVariable int cid) {
		return cs.deleteCategory(cid);
	}

}
