package com.FS_Project.Mobile.API.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.FS_Project.Mobile.API.DAO.CatDao;
import com.FS_Project.Mobile.API.Entity.Category;

@Service
public class CatService {

	
	@Autowired
	CatDao cd;
	
	
	public Category setCategory(Category category) {
	return cd.saveCategory(category);
	}
	
	public Category getCategory(int cid) {
		return cd.getCategory(cid);
	}

	
	public List<Category> getAllCategory() {
		List<Category>list=cd.getAllCategory();
		return list;
	}
	
	
	public Category updateCategory(Category category) {
		return cd.updateCategory(category);
	}

	public Category deleteCategory(int cid) {
		return cd.deleteCategory(cid);
	}
	
}
