package com.FS_Project.Mobile.API.Entity;

public class ObjectNotFoundException extends RuntimeException {

	public ObjectNotFoundException(String message) {
		super(message);
	}

	
	
	
}
