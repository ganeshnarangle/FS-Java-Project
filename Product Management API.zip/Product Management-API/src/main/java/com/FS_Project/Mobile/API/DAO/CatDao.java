package com.FS_Project.Mobile.API.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.FS_Project.Mobile.API.Entity.Category;

@Repository
public class CatDao {

	@Autowired
	SessionFactory sf;
	
	public Category saveCategory(@RequestBody Category category){
		
		Session ss=sf.openSession();
		Transaction tr= ss.beginTransaction();
		ss.save(category);
		tr.commit();
		return category;
		
	}
	
	public Category getCategory(int cid) {
		Session ss=sf.openSession();
		Category category=ss.get(Category.class,cid); 
		//get works only on id.
//		Criteria cr=ss.createCriteria(Category.class);
//		cr.add(Restrictions.eq("cid", cid));
//		List<Category>list=cr.list();
//		Category category=list.get(cid);
		return category;
	}

	
	
	public List<Category> getAllCategory() {
		Session ss=sf.openSession();
		Criteria cr=ss.createCriteria(Category.class);
		List<Category>list=cr.list();
		return list;
	}
	
	
	
	
	
	
	
	
	public Category updateCategory(Category category) {
     Session ss=sf.openSession();
     Transaction tr=ss.beginTransaction();
      ss.update(category);
		tr.commit();
		
		return category;
	}

	public Category deleteCategory(int cid) {

		Session ss=sf.openSession();
	    
		Category category=ss.get(Category.class,cid);
		Transaction tr=ss.beginTransaction();
	      ss.delete(category);
			tr.commit();
			
			return category;
	}
		
	}
	
	
	
	
	
	
